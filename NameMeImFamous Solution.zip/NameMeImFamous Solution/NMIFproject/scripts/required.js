﻿/**

* @author admin

*/
include('scripts/NMIF.js')

